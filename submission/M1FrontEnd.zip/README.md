# CodeBridge AI frontend | COMP 4537 Milestone 1

Extract this archive into its own folder. Run commands from that folder, which contains `frontend/` and `lang/`. Keep those directories side by side. Vite and React import the shared English message catalog from `lang/`.

## Local development

Install Node.js 20.19+ (20.x) or 22.12+ and npm. Start the Express API using the instructions in `M1BackEnd.zip`. The default API is `http://localhost:3000/api/v1`.

If you want to set the API URL explicitly or use a different port, copy `frontend/.env.example` to `frontend/.env.local` and edit `VITE_API_BASE_URL`. On PowerShell use `Copy-Item frontend/.env.example frontend/.env.local`. On macOS/Linux use `cp frontend/.env.example frontend/.env.local`. Keep the `/api/v1` suffix. Vite exposes this value to browsers, so use a URL without credentials and restart Vite after changing it.

```sh
npm --prefix frontend ci
npm --prefix frontend run dev
```

Open [the local frontend](http://localhost:5173). Use `localhost` for both the frontend and API so the browser can use the session cookie. The backend's `CLIENT_ORIGIN` must be exactly `http://localhost:5173` for this setup.

## Instructor smoke test

1. Register a disposable account with a unique email and a password of at least eight characters. Log in, reload **My Questions** to confirm the session persists, then log out from **Profile**. Confirm that visiting `/questions` redirects to login.
2. Log in again. Create a question with **New Question** and enter `why my api returns 404` as its title. Save it, find it in **My Questions**, then edit its details and save again. Reopen it to verify the edit.
3. With llama.cpp running as documented in the backend archive, edit the question and select **Improve with AI**. Review the rewrite, select **Accept suggestion**, and save. Reopen the question to verify the saved change. Use **Delete Question** in the editor and confirm it disappears from the list.

Run the frontend's automated tests with `npm --prefix frontend test`.

## Production build

Set `VITE_API_BASE_URL` in the build environment to the public HTTPS API URL ending in `/api/v1`, for example `https://api.example.com/api/v1`. When a single origin serves the frontend and proxies `/api/v1` to Express, the default relative URL works.

```sh
npm --prefix frontend run build
```

Publish `frontend/dist/`. Set the static host to serve `index.html` for client-side routes such as `/questions`. The included `netlify.toml` and `frontend/public/_redirects` configure the build and routing for Netlify. The optional frontend Dockerfile uses the included placeholder-based Caddy configuration. Set `CLIENT_ORIGIN` on Express to the published frontend origin and follow the backend's production cookie settings.
