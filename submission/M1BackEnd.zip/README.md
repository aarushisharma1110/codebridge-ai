# CodeBridge AI backend | COMP 4537 Milestone 1

Extract this archive into its own folder. Run commands from that folder, which contains `backend/`, `lang/`, and `docker-compose.yml`. Keep `backend/` and `lang/` side by side for the shared English message catalog.

## Local development

Install Node.js 20.19+ (20.x) or 22.12+, npm, and Docker with the Compose plugin. Start Docker. Copy the root `.env.example` to `.env` with `Copy-Item .env.example .env` in PowerShell or `cp .env.example .env` on macOS/Linux.

Choose a fresh local PostgreSQL password using letters and numbers and replace `replace_with_local_password` in both `POSTGRES_PASSWORD` and `DATABASE_URL`. Keep `POSTGRES_USER=codebridge` and `POSTGRES_DB=codebridge_ai` for the bundled Compose setup. Generate a signing secret and paste the result into `JWT_SECRET`.

```sh
node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"
```

Keep `CLIENT_ORIGIN=http://localhost:5173` and `SESSION_COOKIE_SAME_SITE=lax` for the default frontend setup. Keep the root `.env` private.

```sh
docker compose up -d --wait postgres
docker compose exec postgres psql -U codebridge -d codebridge_ai -c "\dt"
npm --prefix backend ci
npm --prefix backend start
```

Compose publishes PostgreSQL on `127.0.0.1:5433` and runs `backend/db/schema.sql` when it initializes an empty volume. The table listing should contain `users`, `questions`, and `api_usage`. To apply the bundled schema to an existing local Compose database, run the following after starting PostgreSQL.

```sh
docker compose exec postgres psql -v ON_ERROR_STOP=1 -U codebridge -d codebridge_ai -f /docker-entrypoint-initdb.d/01-schema.sql
```

Check the API at [the health endpoint](http://localhost:3000/api/v1/health) and the database at [the development diagnostic](http://localhost:3000/api/v1/db-test). Start the frontend using its own README and register a disposable account to test authentication and questions. Run `npm --prefix backend test` for the backend tests. For database integration tests, point `TEST_DATABASE_URL` at a disposable PostgreSQL database whose role can create schemas, then run `npm --prefix backend run test:postgres`.

## AI model setup

1. Download and extract a llama.cpp CPU build for your operating system and CPU architecture. Add its directory to `PATH` or run the executable by its full path. [Official llama.cpp releases](https://github.com/ggml-org/llama.cpp/releases)
2. Download `qwen2.5-3b-instruct-q4_k_m.gguf` (about 2.1 GB) to a separate model directory. [Qwen's Hugging Face download](https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/blob/main/qwen2.5-3b-instruct-q4_k_m.gguf)
3. Replace the model path in this command and run it in a separate terminal. On Windows, the executable is `llama-server.exe`.

```sh
llama-server -m "/path/to/qwen2.5-3b-instruct-q4_k_m.gguf" --host 127.0.0.1 --port 8080 --alias "Qwen/Qwen2.5-3B-Instruct-GGUF:Q4_K_M"
```

Check that `data[0].id` at [the model listing](http://127.0.0.1:8080/v1/models) matches `AI_MODEL` in the backend's root `.env`. If you change the server's port or alias, update `AI_SERVICE_URL` or `AI_MODEL` and restart Express. For slow CPU inference, increase `AI_TIMEOUT_MS` up to 120000 milliseconds.

An authenticated browser sends the question title to `POST /api/v1/ai/improve-question`. Express validates the session and origin, then sends a prompt and title to llama.cpp's `/v1/chat/completions` using the configured model. Express returns the rewrite to the browser. Keep llama.cpp on loopback for local use. The frontend README includes a smoke test for accepting and saving a suggestion.

## Production deployment notes

For a separate HTTPS deployment, inject credentials, the signing secret, and database connection settings through your host's private environment. Use `NODE_ENV=production`, set `CLIENT_ORIGIN` to the exact HTTPS frontend origin, and keep llama.cpp reachable only through a private connection from Express. The default `SESSION_COOKIE_SAME_SITE=lax` works for same-site origins. Use `SESSION_COOKIE_SAME_SITE=none` for separate sites over HTTPS.

The included `deploy/migrate.sql` is the production migration for provisioning the application role and granting access. Its `\ir schema.sql` expects the bundled `backend/db/schema.sql` next to the migration at execution time. The original deployment mounts them side by side. The migration expects a private `APP_DB_PASSWORD` environment variable and runs with psql in a single transaction under a database administrator. Local initialization uses the Compose steps above.
